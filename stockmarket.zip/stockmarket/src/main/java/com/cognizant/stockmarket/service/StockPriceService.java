package com.cognizant.stockmarket.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.stockmarket.entity.Company;
import com.cognizant.stockmarket.entity.StockPrice;
import com.cognizant.stockmarket.repository.StockRepository;

@Component
public class StockPriceService {

	@Autowired
	private StockRepository stockPriceRepo;

	public void addStockPrice(StockPrice sp) {
		stockPriceRepo.save(sp);
	}

	

	
}
