import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'compare-charts',
  templateUrl: './compare-charts.component.html',
  styleUrls: ['./compare-charts.component.scss']
})
export class CompareChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
