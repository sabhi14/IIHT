import { Time } from '@angular/common';

export interface StockPrice {
    company: string;
    stockExchange: string;
    stockPrice: number;
    date: Date;
  }
  