export interface StockExchange {
    stockExchangeName: string;
    brief: string;
    contactAddress: string;
    remarks : string;
  }
  