import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin/admin.component';
import { AddCompanyComponent } from './admin/add-company/add-company.component';
import { UpdateCompanyComponent } from './admin/update-company/update-company.component';
import { AddStockExchangeComponent } from './admin/add-stock-exchange/add-stock-exchange.component';
import { SignInComponent } from './common/sign-in/sign-in.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { SignUpComponent } from './common/sign-up/sign-up.component';
import { UserComponent } from './user/user/user.component';
import { CompareDetailsComponent } from './user/compare-details/compare-details.component';
import { CompareChartsComponent } from './user/compare-charts/compare-charts.component';
import { UploadComponent } from './admin/upload/upload.component';
import { DetailsComponent } from './user/details/details.component';
import { UpdateIpoComponent } from './admin/update-ipo/update-ipo.component';
import { ManageIpoComponent } from './user/manage-ipo/manage-ipo.component';
import { ListCompanyComponent } from './admin/list-company/list-company.component';
import { UpdateDetailsComponent } from './user/update-details/update-details.component';
import { IpoListComponent } from './admin/ipo-list/ipo-list.component';
import { AppService } from './app.service';
import { ChartsOverPeriodComponent } from './user/charts-over-period/charts-over-period.component';

import { FusionChartsModule } from "angular-fusioncharts";
// Import FusionCharts library and chart modules
import * as FusionCharts from "fusioncharts";
import * as Charts from "fusioncharts/fusioncharts.charts";

import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import { SingleCompanyOverDifferentPeriodChartsComponent } from './user/single-company-over-different-period-charts/single-company-over-different-period-charts.component';
import { TwoCompaniesOverSamePeriodChartsComponent } from './user/two-companies-over-same-period-charts/two-companies-over-same-period-charts.component';
import { SingleSectorOverDifferentPeriodChartsComponent } from './user/single-sector-over-different-period-charts/single-sector-over-different-period-charts.component';
FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme);


@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AddCompanyComponent,
    UpdateCompanyComponent,
    AddStockExchangeComponent,
    SignInComponent,
    HeaderComponent,
    FooterComponent,
    SignUpComponent,
    UserComponent,
    CompareDetailsComponent,
    CompareChartsComponent,
    UploadComponent,
    DetailsComponent,
    UpdateIpoComponent,
    ManageIpoComponent,
    ListCompanyComponent,
    UpdateDetailsComponent,
    IpoListComponent,
    ChartsOverPeriodComponent,
    SingleCompanyOverDifferentPeriodChartsComponent,
    TwoCompaniesOverSamePeriodChartsComponent,
    SingleSectorOverDifferentPeriodChartsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    FusionChartsModule,
    ReactiveFormsModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
