export interface User {
    usId: number;
    usName: string;
    password: number;
    userType: string;
    email: string;
    mobileNo: number;
    confirmed: Boolean;
  }
  