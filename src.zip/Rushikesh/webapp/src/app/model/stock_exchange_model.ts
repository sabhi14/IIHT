export interface Company {
    stockExchangeId: number;
    stockExchange: string;
    brief: string;
    contactAddress: string;
    remarks : string;
  }
  