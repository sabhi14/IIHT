export interface IpoDetails {
    ipoId: number;
    companyName: string;
    stockExchange: string;
    pricePerShare: number;
    totalNoShares: number;
    openDateTime: string;
    remarks: string; 
  }
  