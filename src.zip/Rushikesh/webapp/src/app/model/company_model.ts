export interface Company {
    companyId: number;
    companyName: string;
    turnover: number;
    ceo: string;
    boardOfDirectors : string;
    stockExchanges: string;
    isCompanyBlocked: boolean;
    sector: string;
    companyStockCode: string;
  }
  