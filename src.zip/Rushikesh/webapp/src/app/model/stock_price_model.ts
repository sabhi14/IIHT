export interface StockPrice {
    stockPriceId: number;
    companyCode: string;
    stockExchange: string;
    currentPrice: number;
    stockPriceDate: Date;
    stockPriceTime: String;
  }
  