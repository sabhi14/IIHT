export interface Sector {
   sectorId: number;
   sectorName: string;
   brief: string;
  }
  