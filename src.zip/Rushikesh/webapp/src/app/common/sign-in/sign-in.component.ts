import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {

  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
  }

  logInAdmin(formData){
    console.log('ADMIN');
    console.log(formData)
    this.router.navigateByUrl('/admin');
    // this.appService.signIn(formData.userName, formData.password);
  }
  logInUser(formData){
    console.log('USER');
    console.log(formData)
    this.router.navigateByUrl('/user');
  }
}
