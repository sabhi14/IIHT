import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  signUpUser(formData){
    console.log('User signup data');
    console.log(formData)
    if(formData.password != formData.confirmPassword){
      alert('Password not matched.');
      return;
    }
    console.log(formData)
  }
}
